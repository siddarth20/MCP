"""Deterministic business policy. This is the single source of truth for WHAT
is allowed. The LLM interprets text and orchestrates tools; it never decides
whether money moves - these pure functions do, and the tools enforce them."""
from dataclasses import dataclass, asdict

import config
from data_loader import norm_name

INTENTS = {"POINT_CREDIT", "TIER_REVIEW", "NO_ACTION_NEEDED", "UNCLEAR"}
REASONS = {"SYSTEM_ERROR", "PROMO_NOT_CREDITED", "MISSING_POINTS", "BALANCE_MISTAKE", "OTHER"}
CONFIRMED_ERROR_CATEGORIES = {"SYSTEM_ERROR_CONFIRMED", "PROMO_MISCREDIT_CONFIRMED"}

# Which ledger verdicts "clearly support" each customer-stated reason.
REASON_TO_CATEGORIES = {
    "SYSTEM_ERROR": {"SYSTEM_ERROR_CONFIRMED"},
    "PROMO_NOT_CREDITED": {"PROMO_MISCREDIT_CONFIRMED"},
    # Vague claims are supported by any confirmed error on the ledger.
    "MISSING_POINTS": CONFIRMED_ERROR_CATEGORIES,
    "BALANCE_MISTAKE": CONFIRMED_ERROR_CATEGORIES,
}

# Verification statuses
SUPPORTED = "SUPPORTED"          # ledger clearly backs the claim
NOT_SUPPORTED = "NOT_SUPPORTED"  # ledger clearly contradicts it (not eligible)
NEEDS_REVIEW = "NEEDS_REVIEW"    # data/identity/amount/reason problem -> human


@dataclass(frozen=True)
class Decision:
    action: str              # AUTO_CREDIT | AUTO_SCHEDULE_TIER | CLOSE | ESCALATE
    reason: str
    recommended_action: str = "REVIEW"  # what we suggest the human does

    def as_dict(self):
        return asdict(self)


def _result(status, checks, amount, summary, already_credited=False):
    return {"status": status, "checks": checks, "credit_amount_usd": amount,
            "summary": summary, "already_credited": already_credited}


def verify_claim(dispute: dict, record, interp: dict,
                 duplicate_in_source: bool = False, already_credited: bool = False) -> dict:
    """Checks the dispute against its ledger record. Order matters: identity and
    data-integrity problems are checked first, because if we can't trust the
    record, eligibility means nothing."""
    checks = []

    def add(name, passed, detail):
        checks.append({"check": name, "passed": bool(passed), "detail": detail})

    lid = dispute.get("ledger_id", "")
    if record is None:
        add("ledger_record_found", False, f"{lid or '<blank>'} not found in ledger")
        return _result(NEEDS_REVIEW, checks, None, "Ledger record not found")
    add("ledger_record_found", True, f"{lid} found")

    # 1. Data integrity
    cv = record.get("credit_value")
    problems = []
    if duplicate_in_source:
        problems.append("ledger_id appears more than once in source data")
    if cv is None:
        problems.append("credit_value missing or non-numeric")
    elif cv < 0:
        problems.append(f"negative credit_value ({cv})")
    elif not record.get("credit_eligible") and cv > 0:
        problems.append("credit_value > 0 but credit_eligible is FALSE")
    add("ledger_data_integrity", not problems, "; ".join(problems) or "ok")

    # 2. Identity: is this ledger record actually this customer's?
    name_ok = norm_name(dispute.get("customer_name")) == norm_name(record.get("customer_name"))
    add("customer_matches_ledger", name_ok,
        f"dispute='{dispute.get('customer_name')}' ledger='{record.get('customer_name')}'")

    # 3. Does the text point at a DIFFERENT ledger record than the dispute row?
    extra = sorted(set(interp.get("referenced_ledger_ids") or []) - {lid})
    add("ledger_reference_consistent", not extra,
        f"request text references {extra}, dispute row says {lid}" if extra else "ok")

    # 4. Deterministic red flags from the raw text (bypass attempts, third parties, vague asks)
    flags = interp.get("risk_flags") or []
    add("no_risk_flags", not flags, ", ".join(flags) or "ok")

    if problems or not name_ok or extra or flags:
        first_fail = next(c["detail"] for c in checks if not c["passed"])
        return _result(NEEDS_REVIEW, checks, None, f"Needs human check: {first_fail}")

    # 5. Idempotency: never pay the same ledger record twice
    add("not_already_credited", not already_credited,
        "credit already issued by this system for this ledger record" if already_credited else "ok")
    if already_credited:
        return _result(NEEDS_REVIEW, checks, None, "Already credited", already_credited=True)

    # 6. Ledger verdict
    cat = record.get("verified_category")
    if not record.get("credit_eligible"):
        add("credit_eligible", False, f"ledger verdict {cat}: not credit-eligible")
        return _result(NOT_SUPPORTED, checks, None, f"Ledger verdict {cat} does not support a credit")
    add("credit_eligible", True, cat)

    if cv == 0:
        add("outstanding_credit", False, "eligible but credit_value is 0 (likely already credited)")
        return _result(NEEDS_REVIEW, checks, None, "No outstanding credit on ledger")
    add("outstanding_credit", True, f"credit_value={cv}")

    # 7. Does the customer's stated reason match the verified category?
    reason = interp.get("stated_reason", "OTHER")
    allowed = (REASON_TO_CATEGORIES.get(reason, set()) if config.STRICT_REASON_MATCH
               else CONFIRMED_ERROR_CATEGORIES)
    reason_ok = cat in allowed
    add("reason_supported", reason_ok, f"customer reason={reason}, ledger category={cat}")
    if not reason_ok:
        return _result(NEEDS_REVIEW, checks, None, f"Stated reason {reason} not clearly supported by {cat}")

    # 8. Claimed amount vs ledger amount (ledger is the source of truth)
    claimed = interp.get("claimed_amount_usd")
    if claimed is None:
        add("amount_consistent", True, f"no amount stated; ledger credit_value {cv} used")
    else:
        tol = max(config.AMOUNT_TOLERANCE_ABS, config.AMOUNT_TOLERANCE_PCT * cv)
        amt_ok = abs(claimed - cv) <= tol
        add("amount_consistent", amt_ok, f"claimed={claimed}, ledger={cv}, tolerance={tol:.2f}")
        if not amt_ok:
            return _result(NEEDS_REVIEW, checks, None, "Claimed amount differs from ledger")

    return _result(SUPPORTED, checks, round(cv, 2), "Ledger clearly supports the claim")


def decide_credit(interp: dict, verification) -> Decision:
    if interp.get("intent") != "POINT_CREDIT":
        return Decision("ESCALATE", "Not a point-credit request")
    if verification is None:
        return Decision("ESCALATE", "Claim has not been verified")
    status = verification["status"]
    if verification.get("already_credited"):
        return Decision("ESCALATE", "Credit already issued for this ledger record", "CLOSE")
    if status == NOT_SUPPORTED:
        return Decision("ESCALATE", verification["summary"], "DENY")
    if status != SUPPORTED:
        return Decision("ESCALATE", verification["summary"], "REVIEW")
    amount = verification["credit_amount_usd"]
    if amount >= config.AUTO_RESOLVE_LIMIT_USD:
        return Decision("ESCALATE",
                        f"${amount:.2f} is not below the ${config.AUTO_RESOLVE_LIMIT_USD:.2f} auto-resolve limit",
                        "APPROVE_CREDIT")
    return Decision("AUTO_CREDIT", f"Supported by ledger and ${amount:.2f} is under the limit")


def decide_tier(interp: dict, tier) -> Decision:
    if interp.get("intent") != "TIER_REVIEW":
        return Decision("ESCALATE", "Not a tier request")
    if interp.get("risk_flags"):
        return Decision("ESCALATE", f"Risk flags: {', '.join(interp['risk_flags'])}")
    if tier is None:
        return Decision("ESCALATE", "Tier history not looked up")
    if not tier.get("found"):
        # Unknown history is NOT treated as zero - we can't prove they're under the cap.
        return Decision("ESCALATE", "No tier history found for customer; cannot verify cap",
                        "SCHEDULE_TIER_REEVAL")
    if tier.get("ambiguous") or tier.get("effective_count_90d") is None:
        return Decision("ESCALATE", "Tier history is ambiguous or invalid")
    count, cap = tier["effective_count_90d"], config.TIER_REEVAL_CAP
    if count < cap:
        return Decision("AUTO_SCHEDULE_TIER", f"{count} re-evaluations in {config.TIER_WINDOW_DAYS}d is under cap {cap}")
    return Decision("ESCALATE", f"{count} re-evaluations in {config.TIER_WINDOW_DAYS}d reaches cap {cap}", "DENY")


def decide_no_action(interp: dict) -> Decision:
    if interp.get("intent") == "NO_ACTION_NEEDED":
        return Decision("CLOSE", "Customer states nothing further is needed", "CLOSE")
    return Decision("ESCALATE", "Customer is asking for something; cannot close")


# --- Shadow policy check: what the rules alone would do, compared with the LLM ---
TOOL_TO_ACTION = {"issue_credit": "AUTO_CREDIT", "schedule_tier_reevaluation": "AUTO_SCHEDULE_TIER",
                  "close_no_action": "CLOSE", "escalate_to_human": "ESCALATE"}


def reference_decision(interp: dict, verification, tier) -> Decision:
    """The decision the deterministic policy would take on the same facts."""
    intent = interp.get("intent")
    if intent == "NO_ACTION_NEEDED":
        return decide_no_action(interp)
    if intent == "TIER_REVIEW":
        return decide_tier(interp, tier)
    if intent == "POINT_CREDIT":
        return decide_credit(interp, verification)
    return Decision("ESCALATE", "Request is unclear", "REVIEW")


def classify_agreement(llm_action: str, policy_action: str, tool_refused: bool) -> str:
    """AGREE               - LLM chose what the policy would choose (and it executed)
    LLM_MORE_CAUTIOUS      - LLM escalated where the policy would have auto-resolved
    LLM_BLOCKED_BY_TOOL    - LLM tried an action the tool refused (guardrail fired)
    MISMATCH               - anything else (e.g. closed instead of escalating)"""
    if tool_refused:
        return "LLM_BLOCKED_BY_TOOL"
    if llm_action == policy_action:
        return "AGREE"
    if llm_action == "ESCALATE":
        return "LLM_MORE_CAUTIOUS"
    return "MISMATCH"
