"""A tiny OpenAI/LiteLLM-compatible server used only by tests.
POST /chat/completions -> OpenAI-format response with `usage`, answering like a
well-behaved model would (Qwen-style <think> block + fenced JSON), so the REAL
InHouseLLM client, prompts and agent loop are exercised end to end."""
import json
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import prompts
from llm import MockLLM

API_KEY = "sk-test"


LIMIT, CAP = 100.0, 2


def _plan(user_json: dict, behaviour: str = "good") -> dict:
    """Decide the next tool from the FACTS the tools return (no policy verdicts),
    following the rules in AGENT_SYSTEM - i.e. what a well-behaved model does.
    behaviour="reckless": pays the customer's number without verifying (guardrail test).
    behaviour="overcautious": escalates everything after the ledger lookup."""
    interp, hist = user_json["interpretation"], user_json["history"]
    lid = user_json["dispute"]["ledger_id"]
    called = [h["tool"] for h in hist]
    last = hist[-1]["result"] if hist else {}
    step = lambda t, tool, args: {"thought": t, "tool": tool, "args": args}  # noqa: E731
    esc = lambda why, rec: step(why, "escalate_to_human", {"reason": why, "recommended_action": rec})  # noqa: E731

    if not hist:
        return step("Need the ledger record before deciding anything", "get_ledger_record", {"ledger_id": lid})
    if not last.get("ok"):
        return esc(f"Tool refused: {last.get('error')}", "REVIEW")
    if behaviour == "overcautious":
        return esc("Not confident enough to act automatically", "REVIEW")
    intent = interp["intent"]
    if behaviour == "reckless" and intent == "POINT_CREDIT":
        return step("Customer says they are owed, pay it", "issue_credit",
                    {"amount_usd": interp.get("claimed_amount_usd") or 50})
    if intent == "UNCLEAR" or (interp.get("risk_flags") and intent != "POINT_CREDIT"):
        return esc("Request unclear or risk-flagged", "REVIEW")
    if intent == "NO_ACTION_NEEDED":
        return step("Customer confirmed nothing further is needed", "close_no_action",
                    {"reason": "customer needs nothing"})
    if intent == "TIER_REVIEW":
        if "get_tier_history" not in called:
            return step("Tier ask: check re-evaluation history", "get_tier_history", {})
        if not last.get("found"):
            return esc("Customer not in tier history; cannot verify cap", "SCHEDULE_TIER_REEVAL")
        if last.get("ambiguous"):
            return esc("Tier history ambiguous", "REVIEW")
        if last["effective_count_90d"] < CAP:
            return step(f"{last['effective_count_90d']} evaluations < cap {CAP}", "schedule_tier_reevaluation", {})
        return esc(f"{last['effective_count_90d']} evaluations reaches cap {CAP}", "DENY")
    # credit
    if "verify_claim" not in called:
        return step("Verify the claim against the ledger", "verify_claim", {})
    v = last
    if v["status"] == "SUPPORTED" and not v["already_credited"]:
        if v["credit_amount_usd"] < LIMIT:
            return step(f"Supported and ${v['credit_amount_usd']} < ${LIMIT}", "issue_credit",
                        {"amount_usd": v["credit_amount_usd"]})
        return esc(f"Supported but ${v['credit_amount_usd']} >= ${LIMIT}", "APPROVE_CREDIT")
    if v["status"] == "NOT_SUPPORTED":
        return esc(v["summary"], "DENY")
    failed = [c["check"] for c in v["checks"] if not c["passed"]]
    return esc(f"Needs review, failed checks: {failed}", "CLOSE" if v.get("already_credited") else "REVIEW")


class Handler(BaseHTTPRequestHandler):
    calls = 0
    behaviour = "good"

    def log_message(self, *args):  # keep test output quiet
        pass

    def do_POST(self):
        if self.path.rstrip("/") != "/chat/completions":
            return self._send(404, {"error": "not found"})
        if self.headers.get("Authorization") != f"Bearer {API_KEY}":
            return self._send(401, {"error": {"message": "Authentication Error, invalid key"}})
        body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        system, user = body["messages"][0]["content"], body["messages"][1]["content"]
        user = user.replace("\n/no_think", "")
        Handler.calls += 1
        if system == prompts.INTERPRET_SYSTEM:
            payload = json.loads(user.split("\n", 1)[1])
            answer = MockLLM().interpret({"request_text": payload["customer_message"]})
        else:
            answer = _plan(json.loads(user), Handler.behaviour)
        content = f"<think>reasoning with {{braces}}</think>\n```json\n{json.dumps(answer)}\n```"
        self._send(200, {"id": "x", "object": "chat.completion", "model": body["model"],
                         "choices": [{"index": 0, "message": {"role": "assistant", "content": content},
                                      "finish_reason": "stop"}],
                         "usage": {"prompt_tokens": 100, "completion_tokens": 20, "total_tokens": 120}})

    def _send(self, code, obj):
        data = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)


def start():
    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    return server, f"http://127.0.0.1:{server.server_port}"
