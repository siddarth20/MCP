"""LLM layer.
- InHouseLLM: calls the in-house model (OpenAI-compatible /chat/completions).
- MockLLM: deterministic rules with the same interface, for offline runs/tests.
- sanitize_interpretation: validates and GROUNDS whatever the LLM returns
  against the raw text, so hallucinated IDs/amounts never reach the policy."""
import json
import re
import time

import requests

import config
import policy
import prompts
from tools import TOOL_SPECS


class LLMError(Exception):
    pass


LEDGER_RE = re.compile(r"\bLDG-\d+\b", re.IGNORECASE)
AMOUNT_RE = re.compile(r"\$\s?(\d[\d,]*(?:\.\d{1,2})?)")

# Deterministic red flags, computed from the raw text regardless of what the LLM says.
RISK_PATTERNS = {
    # e.g. LP-6258: "supervisor already confirmed ... no need to re-check the ledger"
    "VERIFICATION_BYPASS_ATTEMPT": re.compile(
        r"no need to (re-?)?check|don'?t (re-?)?check|skip (the )?(verification|check)"
        r"|supervisor (already )?(confirmed|approved)|already (confirmed|approved|verified) (this|it)"
        r"|ignore (all|any|previous|the) (rules|instructions)|^\s*system\s*:", re.I | re.M),
    # e.g. LP-6203: "my daughter also had issues with her account"
    "THIRD_PARTY_REFERENCE": re.compile(
        r"\bmy (daughter|son|wife|husband|partner|mother|father|mom|dad|friend|brother|sister)\b"
        r"|\b(her|his|their) account\b", re.I),
}
# A credit is only auto-payable if the customer actually asked for one.
EXPLICIT_CREDIT_ASK = re.compile(
    r"credit (me|my|the)|please credit|i'?m owed|owed \$|fix (my|the)|refund"
    r"|never (showed up|received|arrived)|didn'?t (get|receive)", re.I)


def amounts_in_text(text):
    out = []
    for a in AMOUNT_RE.findall(text or ""):
        try:
            out.append(float(a.replace(",", "")))
        except ValueError:
            pass
    return out


def sanitize_interpretation(raw, text: str) -> dict:
    raw = raw if isinstance(raw, dict) else {}
    notes = []

    intent = str(raw.get("intent", "UNCLEAR")).upper()
    if intent not in policy.INTENTS:
        notes.append(f"invalid intent '{intent}' -> UNCLEAR")
        intent = "UNCLEAR"
    reason = str(raw.get("stated_reason", "OTHER")).upper()
    if reason not in policy.REASONS:
        notes.append(f"invalid reason '{reason}' -> OTHER")
        reason = "OTHER"
    try:
        confidence = max(0.0, min(1.0, float(raw.get("confidence", 0))))
    except (TypeError, ValueError):
        confidence = 0.0

    # Ledger IDs: only IDs literally present in the text count.
    text_ids = sorted({m.upper() for m in LEDGER_RE.findall(text or "")})
    llm_ids = {str(x).upper() for x in (raw.get("referenced_ledger_ids") or [])}
    hallucinated = sorted(llm_ids - set(text_ids))
    if hallucinated:
        notes.append(f"dropped ledger ids not in text: {hallucinated}")

    # Amount: must literally appear in the text.
    claimed = raw.get("claimed_amount_usd")
    text_amounts = amounts_in_text(text)
    try:
        claimed = float(claimed) if claimed is not None else None
    except (TypeError, ValueError):
        claimed = None
    if claimed is not None and not any(abs(claimed - a) < 0.005 for a in text_amounts):
        notes.append(f"dropped claimed amount {claimed} not found in text")
        claimed = None
    if len(set(text_amounts)) > 1:
        notes.append(f"multiple amounts in text {text_amounts}")

    if intent != "UNCLEAR" and confidence < config.MIN_INTERPRETATION_CONFIDENCE:
        notes.append(f"confidence {confidence} below {config.MIN_INTERPRETATION_CONFIDENCE} -> UNCLEAR")
        intent = "UNCLEAR"

    risk_flags = [name for name, rx in RISK_PATTERNS.items() if rx.search(text or "")]
    if intent == "POINT_CREDIT" and not EXPLICIT_CREDIT_ASK.search(text or ""):
        risk_flags.append("NO_EXPLICIT_CREDIT_ASK")  # LLM may be over-reading a vague complaint
    if intent == "TIER_REVIEW" and text_amounts:
        notes.append("secondary credit claim present; tier treated as the real ask, credit NOT auto-processed")

    return {"intent": intent, "stated_reason": reason, "claimed_amount_usd": claimed,
            "referenced_ledger_ids": text_ids, "summary": str(raw.get("summary", ""))[:300],
            "confidence": confidence, "risk_flags": risk_flags, "grounding_notes": notes}


def _extract_json(content: str) -> dict:
    # Qwen3 and other reasoning models may emit <think>...</think> before the answer.
    s = re.sub(r"<think>.*?</think>", "", content or "", flags=re.S)
    s = re.sub(r"```(?:json)?", "", s).strip()
    start, end = s.find("{"), s.rfind("}")
    if start == -1 or end == -1:
        raise LLMError("no JSON object in LLM output")
    return json.loads(s[start:end + 1])


def _dispute_payload(d):
    return {"request_id": d["request_id"], "customer_name": d["customer_name"],
            "customer_tier": d.get("customer_tier"), "ledger_id": d.get("ledger_id"),
            "customer_message": d["request_text"]}


class InHouseLLM:
    """Client for the in-house LiteLLM gateway, mirroring the team's reference code:
    requests.post(f"{LLM_URL}/chat/completions", json=..., headers=..., proxies=...,
                  timeout=..., verify=...)
    One requests.Session is reused for every call (connection pooling)."""
    mode = "inhouse"

    def __init__(self):
        self.url = config.LLM_BASE_URL.rstrip("/") + "/chat/completions"
        self.session = requests.Session()
        self.session.headers.update({"Content-Type": "application/json"})
        if config.LLM_API_KEY:
            self.session.headers["Authorization"] = f"Bearer {config.LLM_API_KEY}"
        # Proxy: explicit value, or none at all (ignore machine-wide proxy env vars)
        self.session.trust_env = False
        if config.LLM_PROXY:
            self.session.proxies = {"http": config.LLM_PROXY, "https": config.LLM_PROXY}
        if config.LLM_CA_BUNDLE:
            self.session.verify = config.LLM_CA_BUNDLE
        elif not config.LLM_VERIFY_SSL:
            self.session.verify = False
            import urllib3
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        self.stats = {"calls": 0, "prompt_tokens": 0, "completion_tokens": 0, "seconds": 0.0}

    def _chat(self, system: str, user: str) -> dict:
        if config.LLM_DISABLE_THINKING:
            user += "\n/no_think"
        payload = {"model": config.LLM_MODEL, "temperature": 0.0, "max_tokens": config.LLM_MAX_TOKENS,
                   "messages": [{"role": "system", "content": system},
                                {"role": "user", "content": user}]}
        last = None
        for attempt in range(1, config.LLM_RETRIES + 1):
            t0 = time.perf_counter()
            try:
                resp = self.session.post(self.url, json=payload, timeout=config.LLM_TIMEOUT_S)
                elapsed = time.perf_counter() - t0
                if resp.status_code != 200:
                    last = f"HTTP {resp.status_code}: {resp.text[:300]}"
                    if 400 <= resp.status_code < 500 and resp.status_code != 429:
                        break  # bad request / auth: retrying will not help
                else:
                    data = resp.json()
                    usage = data.get("usage") or {}
                    self.stats["calls"] += 1
                    self.stats["seconds"] += elapsed
                    self.stats["prompt_tokens"] += usage.get("prompt_tokens") or 0
                    self.stats["completion_tokens"] += usage.get("completion_tokens") or 0
                    if config.LLM_VERBOSE:
                        print(f"      LLM ok {elapsed:.2f}s, tokens={usage.get('total_tokens')}")
                    return _extract_json(data["choices"][0]["message"]["content"])
            except requests.exceptions.SSLError as e:
                last = (f"SSL error: {e}. Set LLM_CA_BUNDLE to the company CA file "
                        f"(or LLM_VERIFY_SSL=false, as the reference client does).")
                break
            except requests.exceptions.RequestException as e:
                last = f"{type(e).__name__}: {e}"
            except (KeyError, IndexError, ValueError, LLMError) as e:
                last = f"bad LLM response: {e!r}"
            print(f"      LLM call failed (attempt {attempt}/{config.LLM_RETRIES}): {last}")
            if attempt < config.LLM_RETRIES:
                time.sleep(1.5 * attempt)  # small backoff
        raise LLMError(f"in-house LLM call failed: {last}")

    def interpret(self, dispute) -> dict:
        user = prompts.INTERPRET_USER.format(payload=json.dumps(_dispute_payload(dispute)))
        return self._chat(prompts.INTERPRET_SYSTEM, user)

    def next_step(self, session) -> dict:
        tool_list = "\n".join(f"- {k}: {v}" for k, v in TOOL_SPECS.items())
        user = json.dumps({"dispute": _dispute_payload(session.dispute),
                           "interpretation": session.interpretation,
                           "history": [{k: s.get(k) for k in ("tool", "args", "result")}
                                       for s in session.trace if "tool" in s]}, default=str)
        system = prompts.AGENT_SYSTEM.format(tool_list=tool_list, limit=config.AUTO_RESOLVE_LIMIT_USD,
                                             cap=config.TIER_REEVAL_CAP)
        return self._chat(system, user)


class MockLLM:
    """Rule-based stand-in with the same interface. Used when LLM_BASE_URL is
    unset. Good enough for the seed data; NOT a replacement for the real model."""
    mode = "mock-rules"

    NO_ACTION = ("no further credit needed", "just closing", "already been credited",
                 "already resolved", "no action needed", "please disregard")
    TIER = re.compile(r"\btier\b|downgrad|upgrad|re-?evaluat|status level|\b(gold|platinum) status")

    def interpret(self, dispute) -> dict:
        t = dispute["request_text"].lower()
        if any(p in t for p in self.NO_ACTION):
            intent = "NO_ACTION_NEEDED"
        elif self.TIER.search(t):
            intent = "TIER_REVIEW"
        elif EXPLICIT_CREDIT_ASK.search(t):
            intent = "POINT_CREDIT"
        else:
            intent = "UNCLEAR"

        if "system error" in t:
            reason = "SYSTEM_ERROR"
        elif re.search(r"(promo|double-points|bonus).*(never|missing|didn't|not)", t):
            reason = "PROMO_NOT_CREDITED"
        elif re.search(r"never received|missing points|didn't (get|receive)", t):
            reason = "MISSING_POINTS"
        elif "mistake" in t or "wrong" in t:
            reason = "BALANCE_MISTAKE"
        else:
            reason = "OTHER"

        amounts = amounts_in_text(dispute["request_text"])
        return {"intent": intent, "stated_reason": reason,
                "claimed_amount_usd": amounts[0] if amounts else None,
                "referenced_ledger_ids": LEDGER_RE.findall(dispute["request_text"]),
                "summary": f"{intent} ({reason})", "confidence": 0.9 if intent != "UNCLEAR" else 0.3}

    def next_step(self, session) -> dict:
        return RulePlanner.next_step(session)


def _mk_step(thought, tool, args):
    return {"thought": thought, "tool": tool, "args": args}



class RulePlanner:
    """Deterministic planner: follows the same procedure the agent prompt describes,
    using the policy_decision each tool returns. Used by MockLLM and by
    AGENT_PLANNER=rules (real LLM interprets, rules pick the tools)."""
    mode = "rules"

    @staticmethod
    def next_step(session) -> dict:
        _step = _mk_step
        st, interp, lid = session.tools.state, session.interpretation, session.tools.ledger_id
        intent = interp["intent"]

        if lid not in st["ledger_lookups"]:
            return _step("Look up the referenced ledger record first", "get_ledger_record",
                              {"ledger_id": lid})
        if intent == "UNCLEAR":
            return _step("Intent unclear", "escalate_to_human",
                              {"reason": "Could not determine a concrete ask from the customer",
                               "recommended_action": "REVIEW"})
        if intent == "NO_ACTION_NEEDED":
            return _step("Customer says nothing further is needed", "close_no_action",
                              {"reason": "Customer confirmed issue already resolved"})
        if intent == "TIER_REVIEW":
            if st["tier"] is None:
                return _step("Tier ask: check re-evaluation history", "get_tier_history", {})
            d = policy.decide_tier(interp, st["tier"])
            if d.action == "AUTO_SCHEDULE_TIER":
                return _step(d.reason, "schedule_tier_reevaluation", {})
            return _step(d.reason, "escalate_to_human",
                              {"reason": d.reason, "recommended_action": d.recommended_action})
        # POINT_CREDIT
        if st["verification"] is None:
            return _step("Verify the claim against the ledger", "verify_claim", {})
        d = policy.decide_credit(interp, st["verification"])
        if d.action == "AUTO_CREDIT":
            return _step(d.reason, "issue_credit",
                              {"amount_usd": st["verification"]["credit_amount_usd"]})
        return _step(d.reason, "escalate_to_human",
                          {"reason": d.reason, "recommended_action": d.recommended_action})



def get_llm():
    return InHouseLLM() if config.LLM_BASE_URL else MockLLM()


def get_planner(llm):
    """Which component chooses tools in the agent loop (see config.AGENT_PLANNER)."""
    if isinstance(llm, MockLLM) or config.AGENT_PLANNER != "rules":
        return llm
    return RulePlanner()
