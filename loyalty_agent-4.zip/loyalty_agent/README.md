# Loyalty Point Dispute Agent

**Design in one line: the LLM decides, the tools enforce, the policy measures.**

An AI agent that reads customer loyalty-point disputes, checks each one against the
loyalty ledger, and automatically resolves only the safe, low-value, clearly supported
cases. Everything else goes to a human review queue. Every decision, action and override
is stored in PostgreSQL 15.

## Setup
1. Python 3.10+ and PostgreSQL 15 (database `refogdb` on localhost:5432).
2. `pip install -r requirements.txt`
3. Set the connection (see `.env.example`). On Windows PowerShell:
   `$env:PGUSER="postgres"; $env:PGPASSWORD="your_password"`
   On macOS/Linux: `export PGUSER=postgres PGPASSWORD=your_password`
4. Copy `loyalty_point_disputes.csv`, `loyalty_ledger_records.csv`,
   `tier_reevaluation_history.csv` (and optionally `qa-manifest.json`) into `./data/`.
5. Copy `.env.example` to `.env` and fill in the database and LLM settings. The LLM client
   mirrors the team's reference code: `POST {LLM_BASE_URL}/chat/completions` with a Bearer key,
   optional proxy, timeout, and `verify` (set `LLM_VERIFY_SSL=false` or `LLM_CA_BUNDLE`).
   Without `LLM_BASE_URL`, a rule-based MockLLM is used (offline development only).
6. Check connectivity first: `python main.py check-llm`.

Tables are created automatically in schema `loyalty` (override with `PG_SCHEMA`).

## Run (disputes are resolved one at a time; each result prints and is saved immediately)
- `python main.py validate` - data-quality and foreign-key checks only
- `python main.py check-llm` - one test call to the in-house LLM (shows the exact error if it fails)
- `python main.py next` - resolve only the next pending dispute
- `python main.py resolve LP-6263` - resolve one specific dispute (re-resolves if already done)
- `python main.py run` - resolve all pending disputes, one by one
- `python main.py run --step` - pause after each dispute (Enter = next, q = quit)
- `python main.py run --limit 5 --reprocess`
- Ctrl+C stops safely; finished disputes are already in the database.
- `python review.py list --status PENDING_REVIEW` / `show LP-6228` / `override ...`
- `python review.py agreement` - how often the LLM's decisions matched the policy, and every disagreement
- `python -m pytest -q` - tests use throwaway `test_xxxxxxxx` schemas and drop them afterwards

LLM options (in `.env`): `LLM_PROXY`, `LLM_VERIFY_SSL` / `LLM_CA_BUNDLE`, `LLM_TIMEOUT_S`,
`LLM_MAX_TOKENS`, `LLM_RETRIES`, `LLM_VERBOSE=true` (per-call timing and tokens),
`AGENT_PLANNER=llm|rules` (see RATIONALE.md). Each dispute prints its LLM calls, tokens and time.

## Useful SQL
```sql
SELECT request_id, status, outcome, recommended_action FROM loyalty.decisions ORDER BY request_id;
SELECT * FROM loyalty.actions WHERE action_type = 'ISSUE_CREDIT';
SELECT request_id, interpretation->'risk_flags' FROM loyalty.decisions
 WHERE jsonb_array_length(interpretation->'risk_flags') > 0;
```

Tunables (limit, tolerance, tier cap) are in `config.py` and can be overridden with environment variables.
