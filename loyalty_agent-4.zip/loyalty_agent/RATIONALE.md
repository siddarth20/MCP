# Rationale

**Core decision: the LLM interprets and orchestrates; code decides money.** The in-house LLM
reads the free-text request and drives the tool loop, but whether a credit or tier
re-evaluation is allowed is decided by pure functions in `policy.py`, and every write tool
re-checks that policy. A hallucinating or prompt-injected model can at worst escalate, never pay.

**Approach: the LLM decides, the tools enforce, the policy measures.** Disputes are resolved one
at a time: the LLM interprets the request, then in an agent loop it chooses every tool call and the
final action. Read tools (`get_ledger_record`, `verify_claim`, `get_tier_history`) return *facts only*
(each check, the ledger amount, the tier counts), never a verdict, and the prompt gives goals and rules
rather than a script, so the decision is genuinely the LLM's. Safety does not depend on the LLM being
right: the write tools re-check policy, so a wrong choice is refused and becomes an escalation, never a
payment. Before the LLM's final action, the code independently computes what the deterministic policy
would do and records the agreement (AGREE / LLM_MORE_CAUTIOUS / LLM_BLOCKED_BY_TOOL / MISMATCH).
`python review.py agreement` reports it, which turns "we trust the LLM" into a measured number. Tests
run a well-behaved, a reckless and an overcautious fake model: the reckless one pays nothing. Each
dispute is committed before the next starts. `AGENT_PLANNER=rules` (1 LLM call instead of ~4) is the
production-cost option.

**How I resolved underspecified points**
- *Value threshold:* auto-resolve only if the ledger `credit_value` is below $100 (configurable).
  Large confirmed errors ($190, $460, $480) go to a human with an APPROVE_CREDIT recommendation.
- *"Clearly supported":* the record must belong to the same customer, the request must not cite a
  different ledger id, the data must be sane, `credit_eligible` must be TRUE with a positive value,
  the stated reason must map to the verified category (strict mode), and any claimed amount must be
  within max($1, 5%) of the ledger. The ledger amount is always what gets paid.
- *Not-supported requests* are not auto-denied; they are queued with a DENY recommendation,
  because the brief only authorises autonomous *resolution* of supported cases.
- *Tier cap:* fewer than 2 re-evaluations in the 90-day window, counting ones this app already
  scheduled. A customer missing from the history is escalated, not treated as zero.
- *Name matching* is exact (case/space-insensitive), never fuzzy, since the tier file contains
  near-duplicate names.

**Data traps found (calibrated ids):** LP-6262 asks for nothing; LP-6257 cites LDG-6006 and its ledger
row belongs to another customer; LDG-6251 has a negative credit_value; LP-6258 asks us to skip the
ledger check ("supervisor already confirmed"); LP-6203 is a vague complaint mentioning a daughter's
account, yet its ledger row is eligible for $15, so an over-eager LLM could auto-pay it; LP-6232 claims
$470 but says the real ask is tier status; tier requests (6242/6208/6260) carry irrelevant
CUSTOMER_MISUNDERSTANDING ledger rows, and 6260's name is absent from tier history (only a near-match
exists). Because the LLM could misread any of these, risk flags (bypass attempt, third-party reference,
no explicit credit ask) are computed deterministically from the raw text and force escalation.

**Where I questioned the AI assistant:** TODO - add your real examples here.

**With more time:** a web review UI instead of the CLI; an eval harness scoring the real LLM against
the calibrated ids; bounded parallelism across disputes (one dispute stays sequential internally);
JSON-schema / response_format enforcement if the gateway model supports it; real payment and CRM integrations with
dry-run/approval modes; per-customer daily credit limits; Alembic migrations and a connection pool;
wrapping each credit plus its audit rows in one transaction;
revisit the strict reason-match rule with the business.
