# MANIFEST - Loyalty Point Dispute Agent

## Agent / orchestration logic
- `agent.py` - per-dispute orchestrator: LLM interpretation (step 0), bounded tool loop in which the
  LLM chooses every tool (`MAX_AGENT_STEPS`), shadow policy check before the LLM's final action
  (agreement recorded), forced escalation safety net, reasoning builder, persistence.
- `llm.py` - `InHouseLLM` (`requests.Session` client for the LiteLLM gateway: Bearer auth, proxy,
  timeout, TLS verify/CA bundle, retries with backoff, no retry on 4xx, token/latency stats,
  Qwen3 `<think>` stripping), `MockLLM` (offline stand-in), `RulePlanner` (deterministic tool planner
  used by `AGENT_PLANNER=rules` and the mock), `get_planner`,
  `sanitize_interpretation` (schema validation + grounding of IDs/amounts against the raw text).
- `prompts.py` - interpretation prompt and agent tool-loop prompt (strict JSON, untrusted-input framing).

## Business rules
- `policy.py` - pure functions: `verify_claim`, `decide_credit`, `decide_tier`, `decide_no_action`
  (enforced by the write tools), `reference_decision` + `classify_agreement` (shadow check).
- `config.py` - thresholds: auto-resolve limit ($100), amount tolerance, strict reason match,
  tier cap (2 per 90 days), agent step limits, LLM settings.

## Tool definitions (`tools.py`)
| Tool | Type | Guardrail |
|---|---|---|
| `get_ledger_record(ledger_id)` | read | - |
| `verify_claim()` | read, facts only | requires prior ledger lookup; always the dispute's own ledger id |
| `get_tier_history()` | read, facts only | dispute's own customer only; adds app-scheduled evals to the CSV count |
| `issue_credit(amount_usd)` | write | re-runs policy; amount must equal ledger `credit_value`; DB unique index |
| `schedule_tier_reevaluation()` | write | re-runs tier policy; one pending eval per customer (DB index) |
| `escalate_to_human(reason, recommended_action)` | write | recommendation restricted to an allow-list |
| `close_no_action(reason)` | write | only when intent is NO_ACTION_NEEDED |

## Persistence (`db.py`, PostgreSQL 15 via psycopg 3)
Schema `loyalty` (configurable). Tables: `requests`, `decisions` (JSONB interpretation,
verification, full trace and `shadow` LLM-vs-policy comparison; `agreement`; reasoning; status), `actions`, `tier_reevaluations`,
`overrides`, `tool_calls` (audit of every tool call). CHECK constraints on status and
outcome values; overrides require a non-empty note.
Partial unique indexes: one live credit per ledger record; one pending tier evaluation per
customer. Violations surface as `DuplicateError`. Connection settings come from `PG*` env vars
(`config.pg_conninfo`); no password is stored in code.

## Ingestion
- `data_loader.py` - CSV loading (BOM-safe), required-column checks, typing, duplicate
  ledger detection, FK check from `qa-manifest.json` (`allowed_missing: []`).

## Human review
- `review.py` - `list`, `show` (reasoning, LLM steps, LLM-vs-policy, trace, actions), `agreement`
  (how often the LLM matched policy and where it differed), `override`
  (approve_credit / deny / reverse_credit / schedule_tier / cancel_tier / close; reviewer + note required).

## Entry points and tests
- `main.py` - `validate`, `check-llm`, `next`, `resolve <ids>`, `run [--step]`: disputes are
  resolved one at a time, each printed and committed immediately.
- `tests/fake_llm_server.py` - OpenAI/LiteLLM-compatible fake gateway for end-to-end tests.
- `tests/test_agent.py` - 37 tests incl. the real HTTP client over the fake gateway in both planner
  modes, bad-key handling, and good / reckless / overcautious model behaviour (reckless pays nothing) covering all 13 calibrated ids, idempotency, overrides,
  sanitisation, risk flags, FK. Run against Postgres in isolated throwaway schemas.
