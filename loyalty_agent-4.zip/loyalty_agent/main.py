"""Entry point - disputes are resolved ONE AT A TIME and each result is printed
(and committed to PostgreSQL) as soon as it is decided.

  python main.py validate                  # data-quality + FK checks only
  python main.py check-llm                 # one test call to the in-house LLM
  python main.py next                      # resolve only the next pending dispute
  python main.py resolve LP-6263           # resolve one specific dispute
  python main.py run                       # resolve all pending disputes, one by one
  python main.py run --step                # ...pausing after each (Enter = next, q = quit)
  python main.py run --limit 5 --reprocess
"""
import argparse
import sys
import uuid
from collections import Counter
from pathlib import Path

import config
from agent import iter_resolve, pending_disputes
from data_loader import load_all
from db import DB
from llm import LLMError, get_llm


def print_result(r: dict, idx: int, total: int):
    claimed = f"${r['claimed_amount_usd']:.2f}" if r["claimed_amount_usd"] is not None else "-"
    if r["outcome"] == "CREDIT_ISSUED":
        result = f"CREDIT ISSUED ${r['amount_usd']:.2f}"
    elif r["outcome"] == "TIER_REEVAL_SCHEDULED":
        result = "TIER RE-EVALUATION SCHEDULED"
    elif r["outcome"] == "CLOSED_NO_ACTION":
        result = "CLOSED (no action needed)"
    else:
        result = f"ESCALATED to human (recommend {r['recommended_action']})"
    print(f"\n[{idx}/{total}] {r['request_id']}  {r['customer_name']}  ({r['ledger_id']})")
    print(f"  Request : {r['request_text']}")
    print(f"  Intent  : {r['intent']} / {r['stated_reason']} / claimed {claimed}")
    if r["risk_flags"]:
        print(f"  Flags   : {', '.join(r['risk_flags'])}")
    print(f"  Steps   : {' -> '.join(r['steps']) or '-'}")
    if r["llm_errors"]:
        print(f"  LLM err : {r['llm_errors'][-1][:200]}")
    u = r.get("llm_usage") or {}
    if u.get("calls"):
        print(f"  LLM     : {int(u['calls'])} call(s), {int(u['prompt_tokens'] + u['completion_tokens'])} tokens, "
              f"{u['seconds']:.1f}s")
    print(f"  Result  : {result}")
    print(f"  Why     : {r['reason']}")
    sh = r.get("shadow")
    if sh:
        detail = "" if sh["agreement"] == "AGREE" else \
            f"  <- LLM chose {sh['llm_action']}, policy says {sh['policy_action']}"
        print(f"  Policy  : {sh['agreement']}{detail}")
    sys.stdout.flush()


def print_summary(results):
    if not results:
        print("\nNothing to resolve (all disputes already decided; use --reprocess to redo).")
        return
    print("\n" + "=" * 70)
    print(f"Resolved {len(results)} dispute(s):", dict(Counter(r["outcome"] for r in results)))
    print(f"Total auto-credited: ${sum(r['amount_usd'] or 0 for r in results):.2f}")
    calls = sum((r.get("llm_usage") or {}).get("calls", 0) for r in results)
    if calls:
        toks = sum((r["llm_usage"].get("prompt_tokens", 0) + r["llm_usage"].get("completion_tokens", 0))
                   for r in results)
        secs = sum(r["llm_usage"].get("seconds", 0) for r in results)
        print(f"LLM usage: {int(calls)} calls, {int(toks)} tokens, {secs:.1f}s")
    agree = Counter((r.get("shadow") or {}).get("agreement", "-") for r in results)
    print(f"LLM vs policy: {agree.get('AGREE', 0)}/{len(results)} agree  {dict(agree)}")
    print("Review queue: python review.py list --status PENDING_REVIEW")
    print("Disagreements: python review.py agreement")


def check_llm(llm):
    if llm.mode == "mock-rules":
        print("LLM_BASE_URL is not set - MockLLM in use, nothing to check.")
        return
    print(f"POST {llm.url}\n  model={config.LLM_MODEL} proxy={config.LLM_PROXY or 'none'} "
          f"verify_ssl={config.LLM_CA_BUNDLE or config.LLM_VERIFY_SSL} timeout={config.LLM_TIMEOUT_S}s")
    try:
        out = llm.interpret({"request_id": "PING", "customer_name": "Test", "customer_tier": "Gold",
                             "ledger_id": "LDG-0000",
                             "request_text": "There was a system error, I'm owed $10 worth of points."})
        print(f"LLM OK in {llm.stats['seconds']:.2f}s. Parsed response:", out)
    except LLMError as e:
        print("LLM FAILED:", e)


def main(argv=None):
    p = argparse.ArgumentParser(description="Loyalty point dispute agent")
    p.add_argument("command", choices=["validate", "check-llm", "next", "resolve", "run"])
    p.add_argument("request_ids", nargs="*", help="for 'resolve': one or more request ids")
    p.add_argument("--data-dir", default=str(config.DATA_DIR))
    p.add_argument("--dsn", default=None, help="Postgres conninfo; default from PG* env vars")
    p.add_argument("--schema", default=config.PG_SCHEMA)
    p.add_argument("--limit", type=int)
    p.add_argument("--reprocess", action="store_true", help="redo disputes already decided")
    p.add_argument("--step", action="store_true", help="pause after each dispute")
    args = p.parse_args(argv)

    llm = get_llm()
    if args.command == "check-llm":
        check_llm(llm)
        return

    store = load_all(Path(args.data_dir))
    print(f"Loaded {len(store.disputes)} disputes, {len(store.ledger)} ledger records, "
          f"{len(store.tier_history)} tier-history customers")
    for issue in store.issues:
        print(f"  DATA ISSUE: {issue}")
    if args.command == "validate":
        return

    if llm.mode == "mock-rules":
        print("WARNING: LLM_BASE_URL not set - using rule-based MockLLM (offline mode)")
    else:
        print(f"Using in-house LLM: {config.LLM_MODEL} at {llm.url} "
              f"(tool planner: {'LLM' if config.AGENT_PLANNER != 'rules' else 'rules'})")

    only, limit, reprocess = None, args.limit, args.reprocess
    if args.command == "resolve":
        if not args.request_ids:
            p.error("resolve needs at least one request id, e.g. python main.py resolve LP-6263")
        only, reprocess = set(args.request_ids), True   # explicit request = always (re)resolve
        unknown = only - {d["request_id"] for d in store.disputes}
        if unknown:
            p.error(f"unknown request id(s): {sorted(unknown)}")
    elif args.command == "next":
        limit = 1

    db = DB(args.dsn, schema=args.schema)
    run_id = uuid.uuid4().hex[:8]
    total = len(list(pending_disputes(store, db, only, reprocess)))
    total = min(total, limit) if limit else total
    print(f"Run {run_id}: {total} dispute(s) to resolve, one at a time")

    results = []
    try:
        for i, r in enumerate(iter_resolve(store, db, llm, run_id, only, limit, reprocess), 1):
            results.append(r)
            print_result(r, i, total)
            if args.step and i < total:
                if input("  [Enter] next dispute, [q] quit: ").strip().lower() == "q":
                    break
    except KeyboardInterrupt:
        print("\nStopped by user. Finished disputes are already saved.")
    finally:
        print_summary(results)
        db.close()


if __name__ == "__main__":
    main()
