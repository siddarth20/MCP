# Loyalty Point Dispute Agent

An AI agent that reads customer loyalty-point disputes, checks each one against the
loyalty ledger, and automatically resolves only the safe, low-value, clearly supported
cases. Everything else goes to a human review queue. Every decision, action and override
is stored in PostgreSQL 15.

## Setup
1. Python 3.10+ and PostgreSQL 15 (database `refogdb` on localhost:5432).
2. `pip install -r requirements.txt`
3. Set the connection (see `.env.example`). On Windows PowerShell:
   `$env:PGUSER="postgres"; $env:PGPASSWORD="your_password"`
   On macOS/Linux: `export PGUSER=postgres PGPASSWORD=your_password`
4. Copy `loyalty_point_disputes.csv`, `loyalty_ledger_records.csv`,
   `tier_reevaluation_history.csv` (and optionally `qa-manifest.json`) into `./data/`.
5. Optional: set `LLM_BASE_URL` / `LLM_MODEL` / `LLM_API_KEY` for the in-house LLM.
   Without them, a rule-based MockLLM is used (for offline development only).

Tables are created automatically in schema `loyalty` (override with `PG_SCHEMA`).

## Run
- `python main.py validate` - data-quality and foreign-key checks only
- `python main.py run` - process all undecided disputes
- `python main.py run --only LP-6257 LP-6263 --reprocess`
- `python review.py list --status PENDING_REVIEW`
- `python review.py show LP-6228`
- `python review.py override LP-6228 --action approve_credit --reviewer alice --note "checked with finance"`
- `python -m pytest -q` - tests use throwaway `test_xxxxxxxx` schemas and drop them afterwards

## Useful SQL
```sql
SELECT request_id, status, outcome, recommended_action FROM loyalty.decisions ORDER BY request_id;
SELECT * FROM loyalty.actions WHERE action_type = 'ISSUE_CREDIT';
SELECT request_id, interpretation->'risk_flags' FROM loyalty.decisions
 WHERE jsonb_array_length(interpretation->'risk_flags') > 0;
```

Tunables (limit, tolerance, tier cap) are in `config.py` and can be overridden with environment variables.
