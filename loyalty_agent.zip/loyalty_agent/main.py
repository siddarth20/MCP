"""Entry point.
  python main.py validate                 # data-quality + FK checks only
  python main.py run                      # process all unprocessed disputes
  python main.py run --only LP-6257 LP-6263 --reprocess
"""
import argparse
import uuid
from collections import Counter
from pathlib import Path

import config
from agent import run_all
from data_loader import load_all
from db import DB
from llm import get_llm


def main(argv=None):
    p = argparse.ArgumentParser(description="Loyalty point dispute agent")
    p.add_argument("command", choices=["run", "validate"])
    p.add_argument("--data-dir", default=str(config.DATA_DIR))
    p.add_argument("--dsn", default=None, help="Postgres conninfo; default from PG* env vars")
    p.add_argument("--schema", default=config.PG_SCHEMA)
    p.add_argument("--only", nargs="*", help="request_ids to process")
    p.add_argument("--limit", type=int)
    p.add_argument("--reprocess", action="store_true", help="re-run requests already decided")
    args = p.parse_args(argv)

    store = load_all(Path(args.data_dir))
    print(f"Loaded {len(store.disputes)} disputes, {len(store.ledger)} ledger records, "
          f"{len(store.tier_history)} tier-history customers")
    for issue in store.issues:
        print(f"  DATA ISSUE: {issue}")
    if args.command == "validate":
        return

    llm = get_llm()
    if llm.mode == "mock-rules":
        print("WARNING: LLM_BASE_URL not set - using rule-based MockLLM (offline mode)")
    db = DB(args.dsn, schema=args.schema)
    run_id = uuid.uuid4().hex[:8]
    results = run_all(store, db, llm, run_id, only=set(args.only or []) or None,
                      limit=args.limit, reprocess=args.reprocess)

    print(f"\nRun {run_id}: {len(results)} requests processed\n")
    print(f"{'REQUEST':<9} {'STATUS':<17} {'OUTCOME':<22} {'AMOUNT':>8}  REASON")
    for r in results:
        amt = f"{r['amount_usd']:.2f}" if r["amount_usd"] is not None else "-"
        rec = f" [recommend {r['recommended_action']}]" if r["recommended_action"] else ""
        print(f"{r['request_id']:<9} {r['status']:<17} {r['outcome']:<22} {amt:>8}  {r['reason']}{rec}")
    print("\nSummary:", dict(Counter(r["outcome"] for r in results)))
    total = sum(r["amount_usd"] or 0 for r in results)
    print(f"Total auto-credited: ${total:.2f}")
    db.close()


if __name__ == "__main__":
    main()
