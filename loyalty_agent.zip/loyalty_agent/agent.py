"""Agent orchestrator. Per dispute:
  1. LLM interprets the request -> validated/grounded interpretation
  2. Bounded loop: LLM picks a tool, the guarded ToolBox executes it
  3. If no safe terminal action is reached -> forced escalation to a human
  4. Reasoning, trace and outcome are persisted."""
import traceback
from dataclasses import dataclass, field

import config
from llm import LLMError, sanitize_interpretation
from tools import TOOL_SPECS, ToolBox

STATUS_BY_OUTCOME = {"CREDIT_ISSUED": "AUTO_RESOLVED", "TIER_REEVAL_SCHEDULED": "AUTO_RESOLVED",
                     "CLOSED_NO_ACTION": "CLOSED_NO_ACTION", "ESCALATED": "PENDING_REVIEW"}


@dataclass
class Session:
    dispute: dict
    interpretation: dict
    tools: ToolBox
    trace: list = field(default_factory=list)


def _valid_plan(plan):
    return (isinstance(plan, dict) and plan.get("tool") in TOOL_SPECS
            and isinstance(plan.get("args", {}), dict))


def build_reasoning(interp, state) -> str:
    lines = [f"Interpretation: intent={interp['intent']}, reason={interp['stated_reason']}, "
             f"claimed=${interp['claimed_amount_usd']}, confidence={interp['confidence']}"]
    if interp.get("risk_flags"):
        lines.append(f"  RISK FLAGS: {', '.join(interp['risk_flags'])}")
    for note in interp.get("grounding_notes", []):
        lines.append(f"  note: {note}")
    for lid, rec in state["ledger_lookups"].items():
        if rec:
            lines.append(f"Ledger {lid}: {rec['customer_name']}, {rec['verified_category']}, "
                         f"eligible={rec['credit_eligible']}, credit_value={rec['credit_value']}")
        else:
            lines.append(f"Ledger {lid}: NOT FOUND")
    v = state["verification"]
    if v:
        lines.append(f"Verification: {v['status']} - {v['summary']}")
        for c in v["checks"]:
            lines.append(f"  [{'PASS' if c['passed'] else 'FAIL'}] {c['check']}: {c['detail']}")
    t = state["tier"]
    if t:
        lines.append(f"Tier history: {t}")
    term = state["terminal"] or {}
    lines.append(f"Outcome: {term.get('outcome')} - {term.get('reason')}"
                 + (f" (recommend {term['recommended_action']})" if term.get("recommended_action") else ""))
    return "\n".join(lines)


def process_dispute(dispute, store, db, llm, run_id) -> dict:
    db.upsert_request(dispute)
    decision_id = db.start_decision(dispute["request_id"], run_id, llm.mode)
    trace = []
    interp = {"intent": "UNCLEAR", "stated_reason": "OTHER", "claimed_amount_usd": None,
              "referenced_ledger_ids": [], "summary": "", "confidence": 0.0, "risk_flags": [], "grounding_notes": []}
    tools = ToolBox(store, db, dispute, decision_id, interp)

    try:
        # Step 0: interpretation
        try:
            interp = sanitize_interpretation(llm.interpret(dispute), dispute["request_text"])
        except (LLMError, ValueError) as e:
            interp["grounding_notes"].append(f"LLM interpretation failed: {e}")
        tools.interp = interp
        trace.append({"step": 0, "type": "interpretation", "output": interp})
        session = Session(dispute, interp, tools, trace)

        # Steps 1..N: bounded tool loop
        errors = 0
        for step in range(1, config.MAX_AGENT_STEPS + 1):
            try:
                plan = llm.next_step(session)
            except (LLMError, ValueError) as e:
                plan = None
                trace.append({"step": step, "type": "llm_error", "error": str(e)})
            if not _valid_plan(plan):
                errors += 1
                trace.append({"step": step, "type": "invalid_plan", "plan": plan})
            else:
                result = tools.call(plan["tool"], plan.get("args", {}))
                db.log_tool_call(decision_id, step, plan["tool"], plan.get("args", {}), result)
                trace.append({"step": step, "thought": plan.get("thought", ""), "tool": plan["tool"],
                              "args": plan.get("args", {}), "result": result})
                errors = 0 if result.get("ok") else errors + 1
            if tools.state["terminal"] or errors >= config.MAX_CONSECUTIVE_TOOL_ERRORS:
                break

        # Safety net: never leave a request without a safe outcome
        if not tools.state["terminal"]:
            args = {"reason": "Agent did not reach a safe terminal action (step limit or repeated errors)",
                    "recommended_action": "REVIEW"}
            result = tools.call("escalate_to_human", args)
            db.log_tool_call(decision_id, -1, "escalate_to_human", args, result)
            trace.append({"step": -1, "thought": "forced by orchestrator", "tool": "escalate_to_human",
                          "args": args, "result": result})
        status = STATUS_BY_OUTCOME[tools.state["terminal"]["outcome"]]
    except Exception as e:  # never crash the batch on one bad record
        trace.append({"type": "exception", "error": repr(e), "tb": traceback.format_exc()})
        if not tools.state["terminal"]:
            tools.state["terminal"] = {"outcome": "ESCALATED", "recommended_action": "REVIEW",
                                       "reason": f"Unexpected error: {e!r}"}
        status = "PENDING_REVIEW"

    term = tools.state["terminal"]
    db.finalize_decision(decision_id, intent=interp["intent"], interpretation=interp,
                         verification=tools.state["verification"], outcome=term["outcome"],
                         recommended_action=term.get("recommended_action"),
                         reasoning=build_reasoning(interp, tools.state), trace=trace, status=status)
    return {"request_id": dispute["request_id"], "decision_id": decision_id, "status": status,
            "outcome": term["outcome"], "amount_usd": term.get("amount_usd"),
            "recommended_action": term.get("recommended_action"), "reason": term.get("reason")}


def run_all(store, db, llm, run_id, only=None, limit=None, reprocess=False):
    results = []
    for d in store.disputes:
        if only and d["request_id"] not in only:
            continue
        if not reprocess and db.has_final_decision(d["request_id"]):
            continue
        results.append(process_dispute(d, store, db, llm, run_id))
        if limit and len(results) >= limit:
            break
    return results
