"""Tools the agent can call. Each side-effecting tool re-checks policy itself,
so even a misbehaving LLM cannot issue a credit or schedule a re-evaluation
that the policy does not allow ("defence in depth")."""
from datetime import datetime, timedelta, timezone

import config
import policy
from data_loader import norm_name
from db import DuplicateError

RECOMMENDATIONS = {"APPROVE_CREDIT", "DENY", "REVIEW", "SCHEDULE_TIER_REEVAL", "CLOSE"}

TOOL_SPECS = {
    "get_ledger_record": "Look up a loyalty ledger record. args: {ledger_id}",
    "verify_claim": "Check the dispute against its ledger record; returns checks + policy_decision. args: {}",
    "get_tier_history": "Look up this customer's tier re-evaluations in the last 90 days. args: {}",
    "issue_credit": "Issue the verified credit. args: {amount_usd}",
    "schedule_tier_reevaluation": "Schedule a tier-status re-evaluation. args: {}",
    "escalate_to_human": "Send to the human review queue. args: {reason, recommended_action}",
    "close_no_action": "Close with no action when customer needs nothing. args: {reason}",
}


def _err(msg):
    return {"ok": False, "error": msg}


class ToolBox:
    def __init__(self, store, db, dispute, decision_id, interpretation):
        self.store, self.db, self.dispute = store, db, dispute
        self.decision_id, self.interp = decision_id, interpretation
        self.state = {"ledger_lookups": {}, "verification": None, "tier": None, "terminal": None}

    @property
    def ledger_id(self):
        return (self.dispute.get("ledger_id") or "").strip().upper()

    def call(self, name, args):
        if name not in TOOL_SPECS:
            return _err(f"unknown tool '{name}'")
        if self.state["terminal"] is not None:
            return _err("a terminal action was already taken for this request")
        try:
            return getattr(self, name)(**(args if isinstance(args, dict) else {}))
        except TypeError as e:
            return _err(f"invalid arguments for {name}: {e}")

    # --- read-only tools ----------------------------------------------------
    def get_ledger_record(self, ledger_id=None):
        lid = str(ledger_id or self.ledger_id).strip().upper()
        rec = self.store.ledger.get(lid)
        self.state["ledger_lookups"][lid] = rec
        if rec is None:
            return {"ok": True, "found": False, "ledger_id": lid}
        return {"ok": True, "found": True, "record": rec,
                "duplicate_in_source": lid in self.store.ledger_duplicates}

    def verify_claim(self):
        # Always verifies the dispute's OWN ledger record; the LLM can't redirect it.
        lid = self.ledger_id
        if lid not in self.state["ledger_lookups"]:
            return _err(f"call get_ledger_record for {lid} before verify_claim")
        v = policy.verify_claim(self.dispute, self.state["ledger_lookups"][lid], self.interp,
                                duplicate_in_source=lid in self.store.ledger_duplicates,
                                already_credited=self.db.has_executed_credit(lid))
        self.state["verification"] = v
        return {"ok": True, **v, "policy_decision": policy.decide_credit(self.interp, v).as_dict()}

    def get_tier_history(self):
        # Uses the dispute's customer only; the LLM can't look up someone else.
        name = self.dispute["customer_name"]
        rows = self.store.tier_history.get(norm_name(name), [])
        current = self.dispute.get("customer_tier")
        if not rows:
            t = {"found": False, "customer_name": name, "current_tier": current}
        elif len(rows) > 1 or rows[0] is None:
            t = {"found": True, "ambiguous": True, "customer_name": name, "raw_counts": rows,
                 "effective_count_90d": None}
        else:
            pending = self.db.count_scheduled_tier_evals(name, config.TIER_WINDOW_DAYS)
            t = {"found": True, "ambiguous": False, "customer_name": name, "current_tier": current,
                 "csv_count_90d": rows[0], "pending_scheduled_by_app": pending,
                 "effective_count_90d": rows[0] + pending, "cap": config.TIER_REEVAL_CAP}
        self.state["tier"] = t
        return {"ok": True, **t, "policy_decision": policy.decide_tier(self.interp, t).as_dict()}

    # --- side-effecting tools (policy re-checked here) -----------------------
    def issue_credit(self, amount_usd=None):
        v = self.state["verification"]
        d = policy.decide_credit(self.interp, v)
        if d.action != "AUTO_CREDIT":
            return _err(f"policy blocks auto-credit: {d.reason}")
        amount = v["credit_amount_usd"]  # amount ALWAYS comes from the ledger
        if amount_usd is not None and abs(float(amount_usd) - amount) > 0.005:
            return _err(f"amount_usd {amount_usd} must equal verified ledger amount {amount}")
        try:
            action_id = self.db.insert_action(
                self.decision_id, self.dispute["request_id"], "ISSUE_CREDIT",
                ledger_id=self.ledger_id, amount_usd=amount,
                payload={"verified_category": self.state["ledger_lookups"][self.ledger_id]["verified_category"]})
        except DuplicateError:
            return _err("credit already issued for this ledger record (idempotency guard)")
        self.state["terminal"] = {"outcome": "CREDIT_ISSUED", "recommended_action": None,
                                  "reason": d.reason, "action_id": action_id, "amount_usd": amount}
        return {"ok": True, "action_id": action_id, "amount_usd": amount, "status": "EXECUTED"}

    def schedule_tier_reevaluation(self):
        t = self.state["tier"]
        d = policy.decide_tier(self.interp, t)
        if d.action != "AUTO_SCHEDULE_TIER":
            return _err(f"policy blocks tier re-evaluation: {d.reason}")
        when = (datetime.now(timezone.utc) + timedelta(days=1)).date().isoformat()
        try:
            eval_id = self.db.insert_tier_eval(self.decision_id, self.dispute["request_id"],
                                               self.dispute["customer_name"], t["effective_count_90d"], when)
        except DuplicateError:
            return _err("a re-evaluation is already pending for this customer")
        self.state["terminal"] = {"outcome": "TIER_REEVAL_SCHEDULED", "recommended_action": None,
                                  "reason": d.reason, "tier_eval_id": eval_id, "scheduled_for": when}
        return {"ok": True, "tier_eval_id": eval_id, "scheduled_for": when}

    def escalate_to_human(self, reason="", recommended_action="REVIEW"):
        rec = str(recommended_action).upper()
        rec = rec if rec in RECOMMENDATIONS else "REVIEW"
        reason = str(reason)[:500] or "Escalated without reason"
        self.db.insert_action(self.decision_id, self.dispute["request_id"], "ESCALATE",
                              ledger_id=self.ledger_id or None, status="QUEUED",
                              payload={"reason": reason, "recommended_action": rec})
        self.state["terminal"] = {"outcome": "ESCALATED", "recommended_action": rec, "reason": reason}
        return {"ok": True, "queued_for_review": True, "recommended_action": rec}

    def close_no_action(self, reason=""):
        d = policy.decide_no_action(self.interp)
        if d.action != "CLOSE":
            return _err(f"policy blocks close: {d.reason}")
        self.db.insert_action(self.decision_id, self.dispute["request_id"], "CLOSE_NO_ACTION",
                              ledger_id=self.ledger_id or None, payload={"reason": str(reason)[:500]})
        self.state["terminal"] = {"outcome": "CLOSED_NO_ACTION", "recommended_action": None,
                                  "reason": d.reason}
        return {"ok": True, "closed": True}
