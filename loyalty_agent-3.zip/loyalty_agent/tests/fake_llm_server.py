"""A tiny OpenAI/LiteLLM-compatible server used only by tests.
POST /chat/completions -> OpenAI-format response with `usage`, answering like a
well-behaved model would (Qwen-style <think> block + fenced JSON), so the REAL
InHouseLLM client, prompts and agent loop are exercised end to end."""
import json
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import prompts
from llm import MockLLM

API_KEY = "sk-test"


def _plan(user_json: dict) -> dict:
    """Follow the AGENT_SYSTEM procedure using only what the prompt gives the model."""
    interp, hist = user_json["interpretation"], user_json["history"]
    lid = user_json["dispute"]["ledger_id"]
    called = [h["tool"] for h in hist]
    step = lambda t, tool, args: {"thought": t, "tool": tool, "args": args}  # noqa: E731
    if not hist:
        return step("look up ledger first", "get_ledger_record", {"ledger_id": lid})
    if hist and not hist[-1]["result"].get("ok"):
        return step("tool refused", "escalate_to_human", {"reason": hist[-1]["result"].get("error"),
                                                          "recommended_action": "REVIEW"})
    intent = interp["intent"]
    if intent == "UNCLEAR":
        return step("unclear", "escalate_to_human", {"reason": "unclear request", "recommended_action": "REVIEW"})
    if intent == "NO_ACTION_NEEDED":
        return step("nothing needed", "close_no_action", {"reason": "customer needs nothing"})
    if intent == "TIER_REVIEW":
        if "get_tier_history" not in called:
            return step("check tier history", "get_tier_history", {})
        pd = hist[-1]["result"]["policy_decision"]
    else:
        if "verify_claim" not in called:
            return step("verify claim", "verify_claim", {})
        pd = hist[-1]["result"]["policy_decision"]
        if pd["action"] == "AUTO_CREDIT":
            return step(pd["reason"], "issue_credit", {"amount_usd": hist[-1]["result"]["credit_amount_usd"]})
    if pd["action"] == "AUTO_SCHEDULE_TIER":
        return step(pd["reason"], "schedule_tier_reevaluation", {})
    return step(pd["reason"], "escalate_to_human",
                {"reason": pd["reason"], "recommended_action": pd["recommended_action"]})


class Handler(BaseHTTPRequestHandler):
    calls = 0

    def log_message(self, *args):  # keep test output quiet
        pass

    def do_POST(self):
        if self.path.rstrip("/") != "/chat/completions":
            return self._send(404, {"error": "not found"})
        if self.headers.get("Authorization") != f"Bearer {API_KEY}":
            return self._send(401, {"error": {"message": "Authentication Error, invalid key"}})
        body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        system, user = body["messages"][0]["content"], body["messages"][1]["content"]
        user = user.replace("\n/no_think", "")
        Handler.calls += 1
        if system == prompts.INTERPRET_SYSTEM:
            payload = json.loads(user.split("\n", 1)[1])
            answer = MockLLM().interpret({"request_text": payload["customer_message"]})
        else:
            answer = _plan(json.loads(user))
        content = f"<think>reasoning with {{braces}}</think>\n```json\n{json.dumps(answer)}\n```"
        self._send(200, {"id": "x", "object": "chat.completion", "model": body["model"],
                         "choices": [{"index": 0, "message": {"role": "assistant", "content": content},
                                      "finish_reason": "stop"}],
                         "usage": {"prompt_tokens": 100, "completion_tokens": 20, "total_tokens": 120}})

    def _send(self, code, obj):
        data = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)


def start():
    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    return server, f"http://127.0.0.1:{server.server_port}"
