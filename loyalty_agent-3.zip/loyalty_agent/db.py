"""PostgreSQL 15 persistence (psycopg 3): requests, decisions, actions, tier
re-evaluations, overrides and a full tool-call audit log.

Design notes
- JSONB for interpretation / verification / trace so reviewers can query them.
- Idempotency is enforced by the DATABASE (partial unique indexes), not only by
  application code: at most one live credit per ledger record, at most one
  pending tier re-evaluation per customer.
- Every write commits immediately (autocommit) so the audit trail survives a crash
  mid-batch. An optional `schema` isolates test runs from real data."""
import re

import psycopg
from psycopg.rows import dict_row
from psycopg.types.json import Jsonb

import config


class DuplicateError(Exception):
    """Raised when a DB uniqueness guard blocks a duplicate credit / tier evaluation."""


SCHEMA = """
CREATE TABLE IF NOT EXISTS requests (
    request_id    TEXT PRIMARY KEY,
    customer_name TEXT NOT NULL,
    customer_tier TEXT,
    ledger_id     TEXT,
    submitted_at  TEXT,
    request_text  TEXT NOT NULL,
    ingested_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- One row per agent run per request (history kept; latest = max decision_id)
CREATE TABLE IF NOT EXISTS decisions (
    decision_id         BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    request_id          TEXT NOT NULL REFERENCES requests(request_id),
    run_id              TEXT NOT NULL,
    llm_mode            TEXT,
    intent              TEXT,
    interpretation      JSONB,
    verification        JSONB,
    outcome             TEXT CHECK (outcome IN
                          ('CREDIT_ISSUED','TIER_REEVAL_SCHEDULED','CLOSED_NO_ACTION','ESCALATED')),
    recommended_action  TEXT,
    reasoning           TEXT,
    trace               JSONB,
    status              TEXT NOT NULL CHECK (status IN
                          ('IN_PROGRESS','AUTO_RESOLVED','CLOSED_NO_ACTION','PENDING_REVIEW','OVERRIDDEN','ERROR')),
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_decisions_request ON decisions(request_id, decision_id DESC);
CREATE INDEX IF NOT EXISTS ix_decisions_status ON decisions(status);

CREATE TABLE IF NOT EXISTS actions (
    action_id    BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    decision_id  BIGINT NOT NULL REFERENCES decisions(decision_id),
    request_id   TEXT NOT NULL REFERENCES requests(request_id),
    action_type  TEXT NOT NULL CHECK (action_type IN
                   ('ISSUE_CREDIT','CREDIT_REVERSAL','ESCALATE','CLOSE_NO_ACTION','DENY')),
    ledger_id    TEXT,
    amount_usd   NUMERIC(12,2),
    actor        TEXT NOT NULL,            -- 'agent' or reviewer name
    status       TEXT NOT NULL CHECK (status IN ('EXECUTED','REVERSED','QUEUED')),
    payload      JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
-- Hard guarantee: at most one live credit per ledger record.
CREATE UNIQUE INDEX IF NOT EXISTS ux_one_credit_per_ledger
    ON actions(ledger_id) WHERE action_type = 'ISSUE_CREDIT' AND status = 'EXECUTED';

CREATE TABLE IF NOT EXISTS tier_reevaluations (
    tier_eval_id    BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    decision_id     BIGINT NOT NULL REFERENCES decisions(decision_id),
    request_id      TEXT NOT NULL REFERENCES requests(request_id),
    customer_name   TEXT NOT NULL,
    prior_count_90d INTEGER,
    scheduled_for   DATE NOT NULL,
    actor           TEXT NOT NULL,
    status          TEXT NOT NULL CHECK (status IN ('SCHEDULED','CANCELLED')),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
-- At most one pending re-evaluation per customer.
CREATE UNIQUE INDEX IF NOT EXISTS ux_one_pending_tier_eval
    ON tier_reevaluations(lower(customer_name)) WHERE status = 'SCHEDULED';

CREATE TABLE IF NOT EXISTS overrides (
    override_id     BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    decision_id     BIGINT NOT NULL REFERENCES decisions(decision_id),
    request_id      TEXT NOT NULL REFERENCES requests(request_id),
    reviewer        TEXT NOT NULL,
    override_action TEXT NOT NULL,
    previous_status TEXT,
    note            TEXT NOT NULL CHECK (length(trim(note)) > 0),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS tool_calls (
    call_id     BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    decision_id BIGINT NOT NULL REFERENCES decisions(decision_id),
    step        INTEGER,
    tool        TEXT,
    args        JSONB,
    result      JSONB,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
"""


def _clean(obj):
    """Make any Python object JSON-safe for JSONB (e.g. sets, Decimals)."""
    import json
    return json.loads(json.dumps(obj, default=str))


class DB:
    def __init__(self, conninfo=None, schema=None):
        self.conn = psycopg.connect(conninfo or config.pg_conninfo(), autocommit=True,
                                    row_factory=dict_row)
        self.schema = schema
        if schema:
            if not re.fullmatch(r"[a-z_][a-z0-9_]*", schema):
                raise ValueError("invalid schema name")
            self.conn.execute(f"CREATE SCHEMA IF NOT EXISTS {schema}")
            self.conn.execute(f"SET search_path TO {schema}")
        self.conn.execute(SCHEMA)

    def close(self):
        self.conn.close()

    def drop_schema(self):
        """Test helper: remove an isolated schema."""
        if self.schema:
            self.conn.execute(f"DROP SCHEMA IF EXISTS {self.schema} CASCADE")

    def _one(self, sql, params=()):
        return self.conn.execute(sql, params).fetchone()

    def _all(self, sql, params=()):
        return self.conn.execute(sql, params).fetchall()

    # --- requests / decisions ----------------------------------------------
    def upsert_request(self, d: dict):
        self.conn.execute(
            """INSERT INTO requests (request_id, customer_name, customer_tier, ledger_id,
                                     submitted_at, request_text)
               VALUES (%s,%s,%s,%s,%s,%s) ON CONFLICT (request_id) DO NOTHING""",
            (d["request_id"], d["customer_name"], d.get("customer_tier"), d.get("ledger_id"),
             d.get("submitted_at"), d["request_text"]))

    def start_decision(self, request_id, run_id, llm_mode) -> int:
        return self._one(
            """INSERT INTO decisions (request_id, run_id, llm_mode, status)
               VALUES (%s,%s,%s,'IN_PROGRESS') RETURNING decision_id""",
            (request_id, run_id, llm_mode))["decision_id"]

    def finalize_decision(self, decision_id, *, intent, interpretation, verification,
                          outcome, recommended_action, reasoning, trace, status):
        self.conn.execute(
            """UPDATE decisions SET intent=%s, interpretation=%s, verification=%s, outcome=%s,
                      recommended_action=%s, reasoning=%s, trace=%s, status=%s, updated_at=now()
               WHERE decision_id=%s""",
            (intent, Jsonb(_clean(interpretation)), Jsonb(_clean(verification)), outcome,
             recommended_action, reasoning, Jsonb(_clean(trace)), status, decision_id))

    def set_decision_status(self, decision_id, status):
        self.conn.execute("UPDATE decisions SET status=%s, updated_at=now() WHERE decision_id=%s",
                          (status, decision_id))

    def has_final_decision(self, request_id) -> bool:
        return self._one(
            """SELECT 1 FROM decisions WHERE request_id=%s
               AND status NOT IN ('IN_PROGRESS','ERROR') LIMIT 1""", (request_id,)) is not None

    def latest_decision(self, request_id):
        return self._one("""SELECT * FROM decisions WHERE request_id=%s
                            ORDER BY decision_id DESC LIMIT 1""", (request_id,))

    def get_request(self, request_id):
        return self._one("SELECT * FROM requests WHERE request_id=%s", (request_id,))

    def list_latest(self, status=None):
        sql = """SELECT * FROM (
                   SELECT DISTINCT ON (d.request_id) d.*, r.customer_name, r.ledger_id
                   FROM decisions d JOIN requests r USING (request_id)
                   ORDER BY d.request_id, d.decision_id DESC) latest"""
        if status:
            return self._all(sql + " WHERE status=%s ORDER BY request_id", (status,))
        return self._all(sql + " ORDER BY request_id")

    # --- tool audit ---------------------------------------------------------
    def log_tool_call(self, decision_id, step, tool, args, result):
        self.conn.execute(
            "INSERT INTO tool_calls (decision_id, step, tool, args, result) VALUES (%s,%s,%s,%s,%s)",
            (decision_id, step, tool, Jsonb(_clean(args)), Jsonb(_clean(result))))

    # --- actions ------------------------------------------------------------
    def insert_action(self, decision_id, request_id, action_type, *, ledger_id=None,
                      amount_usd=None, actor="agent", status="EXECUTED", payload=None) -> int:
        try:
            return self._one(
                """INSERT INTO actions (decision_id, request_id, action_type, ledger_id, amount_usd,
                                        actor, status, payload)
                   VALUES (%s,%s,%s,%s,%s,%s,%s,%s) RETURNING action_id""",
                (decision_id, request_id, action_type, ledger_id, amount_usd, actor, status,
                 Jsonb(_clean(payload or {}))))["action_id"]
        except psycopg.errors.UniqueViolation as e:
            raise DuplicateError("credit already live for this ledger record") from e

    def has_executed_credit(self, ledger_id) -> bool:
        return self._one(
            """SELECT 1 FROM actions WHERE ledger_id=%s AND action_type='ISSUE_CREDIT'
               AND status='EXECUTED'""", (ledger_id,)) is not None

    def executed_credit_for_request(self, request_id):
        return self._one(
            """SELECT * FROM actions WHERE request_id=%s AND action_type='ISSUE_CREDIT'
               AND status='EXECUTED' ORDER BY action_id DESC LIMIT 1""", (request_id,))

    def set_action_status(self, action_id, status):
        self.conn.execute("UPDATE actions SET status=%s WHERE action_id=%s", (status, action_id))

    def actions_for_request(self, request_id):
        return self._all("SELECT * FROM actions WHERE request_id=%s ORDER BY action_id", (request_id,))

    def count_executed_credits(self, ledger_id) -> int:
        return self._one(
            """SELECT count(*) AS c FROM actions WHERE ledger_id=%s
               AND action_type='ISSUE_CREDIT' AND status='EXECUTED'""", (ledger_id,))["c"]

    # --- tier re-evaluations ------------------------------------------------
    def insert_tier_eval(self, decision_id, request_id, customer_name, prior_count,
                         scheduled_for, actor="agent") -> int:
        try:
            return self._one(
                """INSERT INTO tier_reevaluations (decision_id, request_id, customer_name,
                          prior_count_90d, scheduled_for, actor, status)
                   VALUES (%s,%s,%s,%s,%s,%s,'SCHEDULED') RETURNING tier_eval_id""",
                (decision_id, request_id, customer_name, prior_count, scheduled_for, actor)
            )["tier_eval_id"]
        except psycopg.errors.UniqueViolation as e:
            raise DuplicateError("a re-evaluation is already pending for this customer") from e

    def count_scheduled_tier_evals(self, customer_name, since_days) -> int:
        return self._one(
            """SELECT count(*) AS c FROM tier_reevaluations
               WHERE lower(customer_name)=lower(%s) AND status='SCHEDULED'
                 AND created_at >= now() - make_interval(days => %s)""",
            (customer_name, since_days))["c"]

    def tier_evals_for_request(self, request_id):
        return self._all("SELECT * FROM tier_reevaluations WHERE request_id=%s ORDER BY tier_eval_id",
                         (request_id,))

    def cancel_tier_evals_for_request(self, request_id) -> int:
        return self.conn.execute(
            """UPDATE tier_reevaluations SET status='CANCELLED'
               WHERE request_id=%s AND status='SCHEDULED'""", (request_id,)).rowcount

    # --- overrides ----------------------------------------------------------
    def insert_override(self, decision_id, request_id, reviewer, action, previous_status, note):
        self.conn.execute(
            """INSERT INTO overrides (decision_id, request_id, reviewer, override_action,
                                      previous_status, note)
               VALUES (%s,%s,%s,%s,%s,%s)""",
            (decision_id, request_id, reviewer, action, previous_status, note))

    def overrides_for_request(self, request_id):
        return self._all("SELECT * FROM overrides WHERE request_id=%s ORDER BY override_id",
                         (request_id,))
