"""Ingests the three seed CSVs, normalises types and runs data-quality checks
(including the foreign-key rule declared in qa-manifest.json)."""
import csv
import json
from dataclasses import dataclass, field
from pathlib import Path

DISPUTES_CSV = "loyalty_point_disputes.csv"
LEDGER_CSV = "loyalty_ledger_records.csv"
TIER_CSV = "tier_reevaluation_history.csv"

REQUIRED_COLUMNS = {
    DISPUTES_CSV: {"request_id", "customer_name", "customer_tier", "ledger_id",
                   "submitted_at", "request_text"},
    LEDGER_CSV: {"ledger_id", "customer_name", "point_source", "point_value_usd",
                 "verified_category", "credit_eligible", "credit_value"},
    TIER_CSV: {"customer_name", "tier_reevaluations_last_90_days"},
}


def norm_name(name) -> str:
    """Case/whitespace-insensitive name key. Deliberately NOT fuzzy: the tier
    file contains near-duplicate names (e.g. 'Oskar Tallmadge' vs 'Oskar Ibarra'),
    so fuzzy matching could apply someone else's history."""
    return " ".join(str(name or "").strip().lower().split())


def _to_bool(value) -> bool:
    return str(value).strip().upper() == "TRUE"


def _to_float(value):
    try:
        return float(str(value).strip())
    except (TypeError, ValueError):
        return None


def _to_int(value):
    f = _to_float(value)
    return int(f) if f is not None and f == int(f) else None


def _read_csv(path: Path) -> list[dict]:
    if not path.exists():
        raise FileNotFoundError(f"Missing seed file: {path}")
    with open(path, newline="", encoding="utf-8-sig") as fh:  # utf-8-sig strips Excel BOM
        reader = csv.DictReader(fh)
        headers = {h.strip() for h in (reader.fieldnames or [])}
        missing = REQUIRED_COLUMNS[path.name] - headers
        if missing:
            raise ValueError(f"{path.name} is missing columns: {sorted(missing)}")
        return [{k.strip(): (v or "").strip() for k, v in row.items() if k} for row in reader]


@dataclass
class DataStore:
    disputes: list[dict]
    ledger: dict[str, dict]
    ledger_duplicates: set[str]
    tier_history: dict[str, list]          # norm_name -> list of counts (len>1 = ambiguous)
    issues: list[str] = field(default_factory=list)


def load_all(data_dir: Path) -> DataStore:
    data_dir = Path(data_dir)
    issues: list[str] = []

    disputes = []
    for r in _read_csv(data_dir / DISPUTES_CSV):
        r["ledger_id"] = r["ledger_id"].upper()
        disputes.append(r)

    ledger: dict[str, dict] = {}
    duplicates: set[str] = set()
    for r in _read_csv(data_dir / LEDGER_CSV):
        lid = r["ledger_id"].upper()
        if lid in ledger:
            duplicates.add(lid)
            issues.append(f"Duplicate ledger_id in ledger file: {lid}")
            continue  # keep first; the dispute will be escalated as ambiguous
        ledger[lid] = {
            "ledger_id": lid,
            "customer_name": r["customer_name"],
            "point_source": r["point_source"],
            "point_value_usd": _to_float(r["point_value_usd"]),
            "verified_category": r["verified_category"].upper(),
            "credit_eligible": _to_bool(r["credit_eligible"]),
            "credit_value": _to_float(r["credit_value"]),
        }

    tier: dict[str, list] = {}
    for r in _read_csv(data_dir / TIER_CSV):
        tier.setdefault(norm_name(r["customer_name"]), []).append(
            _to_int(r["tier_reevaluations_last_90_days"]))

    store = DataStore(disputes, ledger, duplicates, tier, issues)
    issues.extend(validate_foreign_keys(store, data_dir))
    return store


def validate_foreign_keys(store: DataStore, data_dir: Path) -> list[str]:
    """Applies fk_pairs from qa-manifest.json if present (disputes.ledger_id ->
    ledger.ledger_id with allowed_missing=[]). Violations are reported, and the
    affected disputes are escalated by the agent rather than crashing the run."""
    allowed_missing: set[str] = set()
    manifest = Path(data_dir) / "qa-manifest.json"
    if manifest.exists():
        try:
            for pair in json.loads(manifest.read_text()).get("fk_pairs", []):
                allowed_missing |= {str(x).upper() for x in pair.get("allowed_missing", [])}
        except (json.JSONDecodeError, AttributeError):
            pass
    problems = []
    for d in store.disputes:
        lid = d["ledger_id"]
        if lid not in store.ledger and lid not in allowed_missing:
            problems.append(f"FK violation: {d['request_id']} -> {lid or '<blank>'} not in ledger")
    return problems
