"""Human-in-the-loop review CLI.
  python review.py list [--status PENDING_REVIEW]
  python review.py show LP-6228
  python review.py override LP-6228 --action approve_credit --reviewer alice --note "verified with finance"
Override actions: approve_credit | deny | reverse_credit | schedule_tier | cancel_tier | close
Every override requires a reviewer and a note, and is written to the overrides table."""
import argparse
from datetime import datetime, timedelta, timezone
from pathlib import Path

import config
from data_loader import load_all
from db import DB, DuplicateError

OVERRIDE_ACTIONS = ("approve_credit", "deny", "reverse_credit", "schedule_tier", "cancel_tier", "close")


class OverrideError(Exception):
    pass


def apply_override(db, store, request_id, action, reviewer, note, amount=None) -> str:
    if action not in OVERRIDE_ACTIONS:
        raise OverrideError(f"unknown action {action}")
    if not reviewer or not note or not note.strip():
        raise OverrideError("reviewer and a non-empty note are required")
    dec = db.latest_decision(request_id)
    if dec is None:
        raise OverrideError(f"no decision found for {request_id}")
    req = db.get_request(request_id)
    did, lid = dec["decision_id"], req["ledger_id"]

    if action == "approve_credit":
        if amount is None:
            rec = store.ledger.get(lid) if store else None
            amount = rec["credit_value"] if rec else None
        if amount is None or amount <= 0:
            raise OverrideError("no positive ledger credit_value; pass --amount explicitly")
        try:
            db.insert_action(did, request_id, "ISSUE_CREDIT", ledger_id=lid, amount_usd=float(amount),
                             actor=reviewer, payload={"override": True, "note": note})
        except DuplicateError:
            raise OverrideError("a credit is already live for this ledger record; reverse it first")
        msg = f"credit of ${float(amount):.2f} issued"
    elif action == "reverse_credit":
        credit = db.executed_credit_for_request(request_id)
        if credit is None:
            raise OverrideError("no executed credit to reverse")
        db.set_action_status(credit["action_id"], "REVERSED")
        db.insert_action(did, request_id, "CREDIT_REVERSAL", ledger_id=lid, amount_usd=-float(credit["amount_usd"]),
                         actor=reviewer, payload={"reversed_action_id": credit["action_id"], "note": note})
        msg = f"credit ${float(credit['amount_usd']):.2f} reversed"
    elif action == "schedule_tier":
        when = (datetime.now(timezone.utc) + timedelta(days=1)).date().isoformat()
        try:  # human authority may exceed the cap; it is recorded as such
            db.insert_tier_eval(did, request_id, req["customer_name"], None, when, actor=reviewer)
        except DuplicateError:
            raise OverrideError("a re-evaluation is already pending for this customer")
        msg = f"tier re-evaluation scheduled for {when}"
    elif action == "cancel_tier":
        n = db.cancel_tier_evals_for_request(request_id)
        if n == 0:
            raise OverrideError("no scheduled re-evaluation to cancel")
        msg = f"{n} tier re-evaluation(s) cancelled"
    elif action == "deny":
        db.insert_action(did, request_id, "DENY", ledger_id=lid, actor=reviewer, payload={"note": note})
        msg = "request denied"
    else:
        db.insert_action(did, request_id, "CLOSE_NO_ACTION", ledger_id=lid, actor=reviewer, payload={"note": note})
        msg = "closed with no action"

    db.insert_override(did, request_id, reviewer, action, dec["status"], note)
    db.set_decision_status(did, "OVERRIDDEN")
    return msg


def _show(db, request_id):
    dec = db.latest_decision(request_id)
    if dec is None:
        print(f"No decision for {request_id}")
        return
    req = db.get_request(request_id)
    print(f"{request_id} | {req['customer_name']} | {req['ledger_id']} | status={dec['status']}")
    print(f"Request: {req['request_text']}\n")
    print(dec["reasoning"])
    print("\nAgent trace:")
    for s in dec["trace"] or []:
        if "tool" in s:
            ok = s["result"].get("ok")
            print(f"  step {s['step']}: {s['tool']}({s['args']}) -> ok={ok}  | {s.get('thought', '')}")
    print("\nActions:")
    for a in db.actions_for_request(request_id):
        print(f"  #{a['action_id']} {a['action_type']} {a['amount_usd'] or ''} by {a['actor']} [{a['status']}]")
    for t in db.tier_evals_for_request(request_id):
        print(f"  tier eval #{t['tier_eval_id']} for {t['scheduled_for']} by {t['actor']} [{t['status']}]")
    for o in db.overrides_for_request(request_id):
        print(f"  OVERRIDE {o['override_action']} by {o['reviewer']}: {o['note']}")


def main(argv=None):
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--dsn", default=None, help="Postgres conninfo; default from PG* env vars")
    common.add_argument("--schema", default=config.PG_SCHEMA)
    common.add_argument("--data-dir", default=str(config.DATA_DIR))
    p = argparse.ArgumentParser(description="Review and override agent decisions")
    sub = p.add_subparsers(dest="cmd", required=True)
    ls = sub.add_parser("list", parents=[common])
    ls.add_argument("--status")
    sh = sub.add_parser("show", parents=[common])
    sh.add_argument("request_id")
    ov = sub.add_parser("override", parents=[common])
    ov.add_argument("request_id")
    ov.add_argument("--action", required=True, choices=OVERRIDE_ACTIONS)
    ov.add_argument("--reviewer", required=True)
    ov.add_argument("--note", required=True)
    ov.add_argument("--amount", type=float)
    args = p.parse_args(argv)

    db = DB(args.dsn, schema=args.schema)
    if args.cmd == "list":
        for r in db.list_latest(args.status):
            print(f"{r['request_id']:<9} {r['status']:<17} {r['outcome'] or '-':<22} "
                  f"{r['recommended_action'] or '':<20} {r['customer_name']}")
    elif args.cmd == "show":
        _show(db, args.request_id)
    else:
        store = load_all(Path(args.data_dir)) if args.action == "approve_credit" else None
        try:
            print(apply_override(db, store, args.request_id, args.action, args.reviewer, args.note, args.amount))
        except OverrideError as e:
            print(f"Override refused: {e}")
    db.close()


if __name__ == "__main__":
    main()
