# Rationale

**Core decision: the LLM interprets and orchestrates; code decides money.** The in-house LLM
reads the free-text request and drives the tool loop, but whether a credit or tier
re-evaluation is allowed is decided by pure functions in `policy.py`, and every write tool
re-checks that policy. A hallucinating or prompt-injected model can at worst escalate, never pay.

**Approach: one dispute at a time, LLM for judgement, code for money.** Each dispute is
interpreted (LLM), then an agent loop calls guarded tools (ledger lookup -> verify -> act) and the
result is committed before the next dispute starts, so progress is visible and a crash loses
nothing. Every tool returns a `policy_decision`, so the LLM planner only has to follow it; the
write tools re-check policy anyway. `AGENT_PLANNER=rules` swaps the LLM planner for a deterministic
one: same tools, same outcomes, ~1 LLM call per dispute instead of ~4 (tested both ways). I kept the
LLM planner as default because the brief asks for an agent; `rules` is the production-cost option.

**How I resolved underspecified points**
- *Value threshold:* auto-resolve only if the ledger `credit_value` is below $100 (configurable).
  Large confirmed errors ($190, $460, $480) go to a human with an APPROVE_CREDIT recommendation.
- *"Clearly supported":* the record must belong to the same customer, the request must not cite a
  different ledger id, the data must be sane, `credit_eligible` must be TRUE with a positive value,
  the stated reason must map to the verified category (strict mode), and any claimed amount must be
  within max($1, 5%) of the ledger. The ledger amount is always what gets paid.
- *Not-supported requests* are not auto-denied; they are queued with a DENY recommendation,
  because the brief only authorises autonomous *resolution* of supported cases.
- *Tier cap:* fewer than 2 re-evaluations in the 90-day window, counting ones this app already
  scheduled. A customer missing from the history is escalated, not treated as zero.
- *Name matching* is exact (case/space-insensitive), never fuzzy, since the tier file contains
  near-duplicate names.

**Data traps found (calibrated ids):** LP-6262 asks for nothing; LP-6257 cites LDG-6006 and its ledger
row belongs to another customer; LDG-6251 has a negative credit_value; LP-6258 asks us to skip the
ledger check ("supervisor already confirmed"); LP-6203 is a vague complaint mentioning a daughter's
account, yet its ledger row is eligible for $15, so an over-eager LLM could auto-pay it; LP-6232 claims
$470 but says the real ask is tier status; tier requests (6242/6208/6260) carry irrelevant
CUSTOMER_MISUNDERSTANDING ledger rows, and 6260's name is absent from tier history (only a near-match
exists). Because the LLM could misread any of these, risk flags (bypass attempt, third-party reference,
no explicit credit ask) are computed deterministically from the raw text and force escalation.

**Where I questioned the AI assistant:** TODO - add your real examples here.

**With more time:** a web review UI instead of the CLI; an eval harness scoring the real LLM against
the calibrated ids; bounded parallelism across disputes (one dispute stays sequential internally);
JSON-schema / response_format enforcement if the gateway model supports it; real payment and CRM integrations with
dry-run/approval modes; per-customer daily credit limits; Alembic migrations and a connection pool;
wrapping each credit plus its audit rows in one transaction;
revisit the strict reason-match rule with the business.
