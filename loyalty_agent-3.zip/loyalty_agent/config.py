"""Central configuration. Every business threshold lives here so it can be
tuned (and defended) in one place. All values can be overridden via env vars."""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent

# Load .env from the project folder (real environment variables still win).
try:
    from dotenv import load_dotenv
    load_dotenv(BASE_DIR / ".env", override=False)
except ImportError:  # python-dotenv not installed; fall back to real env vars
    pass
DATA_DIR = Path(os.getenv("DATA_DIR", BASE_DIR / "data"))

# --- PostgreSQL 15 ------------------------------------------------------------
# Password is never hard-coded: set PGPASSWORD (or DATABASE_URL) in the environment.
PG_HOST = os.getenv("PGHOST", "localhost")
PG_PORT = int(os.getenv("PGPORT", "5432"))
PG_DATABASE = os.getenv("PGDATABASE", "refogdb")
PG_USER = os.getenv("PGUSER", "postgres")
PG_PASSWORD = os.getenv("PGPASSWORD", "")
DATABASE_URL = os.getenv("DATABASE_URL")  # optional full override
PG_SCHEMA = os.getenv("PG_SCHEMA", "loyalty")  # keeps app tables out of 'public'


def pg_conninfo() -> str:
    if DATABASE_URL:
        return DATABASE_URL
    parts = [f"host={PG_HOST}", f"port={PG_PORT}", f"dbname={PG_DATABASE}", f"user={PG_USER}"]
    if PG_PASSWORD:
        parts.append(f"password={PG_PASSWORD}")
    return " ".join(parts)

# --- Credit auto-resolution -------------------------------------------------
# Requests are auto-resolved only if the ledger credit_value is strictly BELOW
# this limit (brief: "below a reasonable value threshold").
AUTO_RESOLVE_LIMIT_USD = float(os.getenv("AUTO_RESOLVE_LIMIT_USD", "100"))

# Customer's claimed $ vs ledger credit_value: allowed gap = max(ABS, PCT * ledger).
# Covers rounding ("$129" vs 129.49) but not inflated claims.
AMOUNT_TOLERANCE_ABS = 1.00
AMOUNT_TOLERANCE_PCT = 0.05

# If True, the customer's stated reason must map to the ledger's verified
# category (e.g. "system error" must be SYSTEM_ERROR_CONFIRMED). Mismatches go
# to a human instead of being auto-paid.
STRICT_REASON_MATCH = os.getenv("STRICT_REASON_MATCH", "true").lower() == "true"

# --- Tier re-evaluation -----------------------------------------------------
TIER_WINDOW_DAYS = 90  # matches tier_reevaluations_last_90_days in the CSV
# Auto-schedule only if the customer has had FEWER than this many
# re-evaluations in the window (including ones this app already scheduled).
TIER_REEVAL_CAP = int(os.getenv("TIER_REEVAL_CAP", "2"))

# --- Agent / LLM ------------------------------------------------------------
MAX_AGENT_STEPS = 8
MAX_CONSECUTIVE_TOOL_ERRORS = 2
MIN_INTERPRETATION_CONFIDENCE = 0.6

# In-house LLM gateway (LiteLLM, OpenAI-compatible). Calls go to
#   POST {LLM_BASE_URL}/chat/completions
# exactly like the team's reference client. If LLM_BASE_URL is not set, a
# deterministic rule-based MockLLM is used so the app runs offline.
LLM_BASE_URL = os.getenv("LLM_BASE_URL")          # e.g. https://llmaas-....intra  (no /chat/completions)
LLM_MODEL = os.getenv("LLM_MODEL", "inhouse-llm")
LLM_API_KEY = os.getenv("LLM_API_KEY", "")
LLM_TIMEOUT_S = int(os.getenv("LLM_TIMEOUT_S", "100"))
LLM_MAX_TOKENS = int(os.getenv("LLM_MAX_TOKENS", "600"))   # our replies are small JSON objects
LLM_RETRIES = int(os.getenv("LLM_RETRIES", "2"))          # total attempts per call
# Proxy: empty = direct connection. Set e.g. http://proxy.company:8080 if the reference code uses one.
LLM_PROXY = os.getenv("LLM_PROXY", "")
# TLS verification. The reference client uses verify=False because the gateway has a
# company certificate. Prefer LLM_CA_BUNDLE=path/to/company-ca.pem (keeps TLS verified);
# set LLM_VERIFY_SSL=false only if no CA bundle is available.
LLM_VERIFY_SSL = os.getenv("LLM_VERIFY_SSL", "true").lower() == "true"
LLM_CA_BUNDLE = os.getenv("LLM_CA_BUNDLE", "")
LLM_DISABLE_THINKING = os.getenv("LLM_DISABLE_THINKING", "true").lower() == "true"  # Qwen3 '/no_think'
LLM_VERBOSE = os.getenv("LLM_VERBOSE", "false").lower() == "true"

# Who picks the next tool in the agent loop:
#   "llm"   - the LLM chooses every tool call (full agent; ~4-5 LLM calls per dispute)
#   "rules" - the LLM interprets the request (1 call), a deterministic planner drives the
#             same guarded tools. ~4x faster/cheaper, identical outcomes, easier to audit.
AGENT_PLANNER = os.getenv("AGENT_PLANNER", "llm").lower()
